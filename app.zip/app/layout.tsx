import type { Metadata } from "next";
import { Poppins } from "next/font/google";
import Script from "next/script";

// --- IMPORT CSS ---
// Pastikan globals.css ada di folder app yang sama dengan file ini
import "./globals.css";

// Import library (Pastikan sudah npm install)
import "remixicon/fonts/remixicon.css";
import "@fortawesome/fontawesome-svg-core/styles.css";
import { config } from "@fortawesome/fontawesome-svg-core";

// --- IMPORT KOMPONEN ---
import Navbar from "@/components/Navbar";

// Mencegah FontAwesome menambahkan CSS otomatis agar tidak tabrakan
config.autoAddCss = false;

const fontPoppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://freezelogistics.com.au"),
  title: {
    default: "Freeze Logistics | Refrigerated Transport & Cold Chain Australia",
    template: "%s | Freeze Logistics",
  },
  description:
    "Freeze Logistics provides premium frozen goods delivery, cold storage, and refrigerated transport solutions across Australia.",
  keywords: [
    "Refrigerated Transport Australia",
    "Cold Chain Logistics",
    "Frozen Goods Delivery",
    "Freeze Logistics",
  ],
  icons: {
    icon: "/assets/logo_freeze_logistics_nav.ico",
  },
  verification: {
    // Kode verifikasi Search Console Anda
    google: "ZO2KP_6qSUrVmXpRGdKDPlxiXDxId1IRw49xIwhCCMo",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={fontPoppins.className}>
        {/* Google Analytics (gtag.js) - ID: G-PBV5K5CPSE */}
        <Script
          src="https://www.googletagmanager.com/gtag/js?id=G-PBV5K5CPSE"
          strategy="afterInteractive"
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-PBV5K5CPSE');
          `}
        </Script>

        <Navbar />
        <main>{children}</main>
      </body>
    </html>
  );
}
